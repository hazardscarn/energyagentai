Marketing Content Package Summary
Generated: 2025-06-15 12:38:49
Session ID: default_session

CONTENT FILES (1)
==================================================

- albertaenergy_hvac_email_campaign.txt
  Type: email_copy
  Created: 2025-06-15T12:38:35.297866

IMAGE FILES (1)
==================================================

- email_image_20250615_123825.png
  Type: email
  Created: 2025-06-15T12:38:30.086896


HOW TO USE
==========
1. Extract this zip file to your desired location
2. Content files are in the 'content/' folder
3. Images are in the 'images/' folder
4. Use these materials for your marketing campaigns

For support, contact your marketing team.
